package com.example.bmicalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private BmiIndicatorView bmiIndicatorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Adjust padding for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Main java code starts here
        TextView result = findViewById(R.id.result);
        TextView result1 = findViewById(R.id.bmi_result);
        Button button = findViewById(R.id.button);
        EditText height = findViewById(R.id.height);
        EditText weight = findViewById(R.id.weight);
        bmiIndicatorView = findViewById(R.id.bmiIndicatorView);

        button.setOnClickListener(new View.OnClickListener() {

            @SuppressLint({"DefaultLocale", "SetTextI18n"})
            @Override
            public void onClick(View v) {
                try {
                    String heightStr = height.getText().toString();
                    String weightStr = weight.getText().toString();

                    if (!heightStr.isEmpty() && !weightStr.isEmpty()) {
                        int ht = Integer.parseInt(heightStr);
                        int wt = Integer.parseInt(weightStr);

                        double height_m = (double) ht / 100;
                        double BMI = wt / (height_m * height_m);

                        String BMI_RESULT = Double.toString(BMI);
                        if (BMI > 25) {
                            result.setText("You are Overweight!");
                            result.setTextColor(getResources().getColor(android.R.color.holo_red_dark)); // Set text color to red
                            result1.setText(BMI_RESULT);
                        } else if (BMI < 18) {
                            result.setText("You are Underweight!");
                            result.setTextColor(getResources().getColor(android.R.color.holo_orange_dark)); // Set text color to orange
                            result1.setText(BMI_RESULT);

                        } else {
                            result.setText("You are Healthy.");
                            result.setTextColor(getResources().getColor(android.R.color.holo_green_dark)); // Set text color to green
                            result1.setText(BMI_RESULT);

                        }

//                        result1.setText(String.format("BMI: %.2f", BMI));
                        bmiIndicatorView.setBmi((float) BMI); // Set BMI value to custom view
                    } else {
                        result.setText("Enter a valid Height or Weight!");
                        result.setTextColor(getResources().getColor(android.R.color.holo_red_dark)); // Set text color to red
                        result1.setText("");
                    }
                } catch (NumberFormatException e) {
                    result.setText("Invalid input!");
                    result.setTextColor(getResources().getColor(android.R.color.holo_red_dark)); // Set text color to red
                    result1.setText("");
                }
            }
        });
    }
}
