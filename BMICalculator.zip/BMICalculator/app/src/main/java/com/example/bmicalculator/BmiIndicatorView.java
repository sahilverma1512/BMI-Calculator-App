package com.example.bmicalculator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class BmiIndicatorView extends View {

    private Paint paint;
    private Paint arrowPaint;
    private Path arrowPath;
    private float bmi = 0; // Default BMI value

    public BmiIndicatorView(Context context) {
        super(context);
        init();
    }

    public BmiIndicatorView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BmiIndicatorView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arrowPaint.setColor(getResources().getColor(R.color.grey));
        arrowPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        arrowPaint.setStrokeWidth(15);

        arrowPath = new Path(); // Preallocate Path object
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        float radius = width / 2f;

        // Draw the semi-circle
        paint.setColor(Color.GREEN);
        canvas.drawArc(0, 0, width, 2 * height, 180, 60, true, paint);

        paint.setColor(Color.YELLOW);
        canvas.drawArc(0, 0, width, 2 * height, 240, 60, true, paint);

        paint.setColor(Color.RED);
        canvas.drawArc(0, 0, width, 2 * height, 300, 60, true, paint);

        // Calculate the position of the arrow
        float angle;
        if (bmi < 18) {
            angle = 210; // Point to the middle of the orange section
        } else if (bmi > 25) {
            angle = 330; // Point to the middle of the red section
        } else {
            angle = 270; // Point to the middle of the green section
        }

        float arrowX = (float) (radius + radius * Math.cos(Math.toRadians(angle)));
        float arrowY = (float) (radius + radius * Math.sin(Math.toRadians(angle)));

        // Draw the arrow
        canvas.drawLine(radius, radius, arrowX, arrowY, arrowPaint);

        // Draw a smaller arrowhead
        arrowPath.reset(); // Clear the Path object
        float arrowheadSize = 40; // Adjust arrowhead size here
        arrowPath.setFillType(Path.FillType.EVEN_ODD);
        arrowPath.moveTo(arrowX, arrowY);
        arrowPath.lineTo((float) (arrowX - arrowheadSize * Math.cos(Math.toRadians(angle - 20))),
                (float) (arrowY - arrowheadSize * Math.sin(Math.toRadians(angle - 20))));
        arrowPath.lineTo((float) (arrowX - arrowheadSize * Math.cos(Math.toRadians(angle + 20))),
                (float) (arrowY - arrowheadSize * Math.sin(Math.toRadians(angle + 20))));
        arrowPath.close();
        canvas.drawPath(arrowPath, arrowPaint);
    }

    public void setBmi(float bmi) {
        this.bmi = bmi;
        invalidate(); // Redraw the view
    }
}
